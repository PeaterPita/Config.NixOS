
require('fidget').setup {}
